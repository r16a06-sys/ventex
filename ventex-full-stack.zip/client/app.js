const API = "http://localhost:4000/api";
const $ = s => document.querySelector(s);
let token = localStorage.getItem("ventex_token") || "";
let user = JSON.parse(localStorage.getItem("ventex_user") || "null");
let cart = JSON.parse(localStorage.getItem("ventex_cart") || "[]");
let products = [];
const icons = {Electronics:"🎧",Fashion:"👕",Home:"🪴",Beauty:"✨",Sports:"🏀"};
function money(n){return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n)}
function headers(){return {"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})}}
async function api(path,opts={}){const r=await fetch(API+path,{...opts,headers:{...headers(),...(opts.headers||{})}});const d=await r.json().catch(()=>({message:"Server response error"}));if(!r.ok)throw Error(d.message||"Request failed");return d}
function say(t){$("#notice").textContent=t}
function saveCart(){localStorage.setItem("ventex_cart",JSON.stringify(cart));$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function render(){let q=$("#search").value.toLowerCase(),c=$("#category").value;let list=products.filter(p=>(!c||p.category===c)&&(`${p.name} ${p.description||""}`.toLowerCase().includes(q)));$("#products").innerHTML=list.map(p=>`<article class="product"><div class="product-art">${icons[p.category]||"✦"}</div><div class="product-info"><small>${p.category}</small><h3>${esc(p.name)}</h3><small>${esc(p.description||"Curated for you")}</small><div class="price-row"><span class="price">${money(p.price)}</span><button class="primary" onclick="addCart('${p.id}')">Add +</button></div></div></article>`).join("")||"<p>No products found.</p>"}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function loadProducts(){try{products=await api("/products");render()}catch(e){say("Backend is not connected yet. Start the server using the README setup steps.");products=[];render()}}
window.addCart=id=>{let p=products.find(x=>x.id===id);if(!p)return;let item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id:p.id,name:p.name,price:p.price,qty:1});saveCart();say("Added to cart.")};
function renderCart(){$("#cartItems").innerHTML=cart.map(x=>`<div class="cart-line"><span>${esc(x.name)} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join("")||"<p>Your cart is empty.</p>";$("#subtotal").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0))}
function account(){let on=!!token;$("#loginBtn").classList.toggle("hidden",on);$("#registerBtn").classList.toggle("hidden",on);$("#logoutBtn").classList.toggle("hidden",!on);$("#whoami").textContent=user?`${user.name} · ${user.role}`:"Sign in to access your workspace"}
function openAuth(mode){$("#modalTitle").textContent=mode==="register"?"Create account":"Login";$("#nameWrap").classList.toggle("hidden",mode!=="register");$("#authName").required=mode==="register";$("#authForm").dataset.mode=mode;$("#authError").textContent="";$("#modal").classList.remove("hidden")}
$("#loginBtn").onclick=()=>openAuth("login");$("#registerBtn").onclick=()=>openAuth("register");$("#closeModal").onclick=()=>$("#modal").classList.add("hidden");
$("#authForm").onsubmit=async e=>{e.preventDefault();try{let mode=e.currentTarget.dataset.mode;let body={email:$("#authEmail").value,password:$("#authPassword").value};if(mode==="register")body.name=$("#authName").value;let d=await api("/auth/"+mode,{method:"POST",body:JSON.stringify(body)});token=d.token;user=d.user;localStorage.setItem("ventex_token",token);localStorage.setItem("ventex_user",JSON.stringify(user));account();$("#modal").classList.add("hidden");say("Signed in successfully.")}catch(err){$("#authError").textContent=err.message}};
$("#logoutBtn").onclick=()=>{token="";user=null;localStorage.removeItem("ventex_token");localStorage.removeItem("ventex_user");account();say("Logged out.")};
$("#search").oninput=render;$("#category").onchange=render;$("#cartBtn").onclick=()=>{$("#cart").classList.remove("hidden");renderCart()};$("#closeCart").onclick=()=>$("#cart").classList.add("hidden");
$("#checkout").onclick=async()=>{if(!token){$("#cart").classList.add("hidden");openAuth("login");say("Please login before checkout.");return}if(!cart.length)return say("Your cart is empty.");try{let d=await api("/orders",{method:"POST",body:JSON.stringify({items:cart.map(x=>({productId:x.id,quantity:x.qty})),paymentMethod:"COD"})});cart=[];saveCart();renderCart();say(`Order ${d.id} placed. Payment method: Cash on delivery.`)}catch(e){say(e.message)}};
async function workspace(path,method="GET",body){try{let d=await api(path,{method,body:body?JSON.stringify(body):undefined});$("#workspaceOutput").textContent=JSON.stringify(d,null,2)}catch(e){$("#workspaceOutput").textContent=e.message}}
$("#myOrders").onclick=()=>workspace("/orders/mine");
$("#sellerApply").onclick=()=>workspace("/sellers/apply","POST",{storeName:(user?.name||"My")+" Store"});
$("#sellerProducts").onclick=()=>workspace("/seller/products");
$("#adminPanel").onclick=()=>workspace("/admin/overview");
saveCart();account();loadProducts();
