import jwt from 'jsonwebtoken';
export function signToken(user){return jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:'2h'});}
export function auth(req,res,next){
 const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):null;
 if(!token)return res.status(401).json({message:'Login required'});
 try{req.auth=jwt.verify(token,process.env.JWT_SECRET);next()}catch{return res.status(401).json({message:'Invalid or expired session'})}
}
export const allow=(...roles)=>(req,res,next)=>roles.includes(req.auth?.role)?next():res.status(403).json({message:'Permission denied'});
