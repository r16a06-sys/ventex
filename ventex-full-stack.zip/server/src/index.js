import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import {z} from 'zod';
import {prisma} from './db.js';
import {auth,allow,signToken} from './auth.js';

if(!process.env.JWT_SECRET||process.env.JWT_SECRET.length<32)throw new Error('JWT_SECRET must be at least 32 characters');
const app=express();
app.use(helmet());
app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(',')||[],credentials:false}));
app.use(express.json({limit:'100kb'}));
app.use('/api/auth',rateLimit({windowMs:15*60*1000,limit:30}));
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
const userView=u=>({id:u.id,name:u.name,email:u.email,role:u.role,sellerStatus:u.sellerStatus,storeName:u.storeName});
app.get('/api/health',(req,res)=>res.json({ok:true,service:'Ventex API'}));
app.post('/api/auth/register',wrap(async(req,res)=>{
 const s=z.object({name:z.string().min(2).max(80),email:z.string().email(),password:z.string().min(8).max(100)}).parse(req.body);
 const exists=await prisma.user.findUnique({where:{email:s.email.toLowerCase()}});
 if(exists)return res.status(409).json({message:'Email already registered'});
 const passwordHash=await bcrypt.hash(s.password,12);
 const u=await prisma.user.create({data:{name:s.name,email:s.email.toLowerCase(),passwordHash}});
 res.status(201).json({token:signToken(u),user:userView(u)});
}));
app.post('/api/auth/login',wrap(async(req,res)=>{
 const s=z.object({email:z.string().email(),password:z.string().min(1)}).parse(req.body);
 const u=await prisma.user.findUnique({where:{email:s.email.toLowerCase()}});
 if(!u||!await bcrypt.compare(s.password,u.passwordHash))return res.status(401).json({message:'Invalid email or password'});
 res.json({token:signToken(u),user:userView(u)});
}));
app.get('/api/products',wrap(async(req,res)=>{
 const where={active:true,...(req.query.category?{category:String(req.query.category)}:{}),...(req.query.q?{name:{contains:String(req.query.q),mode:'insensitive'}}:{})};
 const rows=await prisma.product.findMany({where,include:{seller:{select:{storeName:true}}},orderBy:{createdAt:'desc'}});
 res.json(rows.map(p=>({...p,price:Number(p.price)})));
}));
app.post('/api/sellers/apply',auth,allow('CUSTOMER','SELLER'),wrap(async(req,res)=>{
 const s=z.object({storeName:z.string().min(2).max(80)}).parse(req.body);
 const u=await prisma.user.update({where:{id:req.auth.sub},data:{role:'SELLER',sellerStatus:'PENDING',storeName:s.storeName}});
 res.json(userView(u));
}));
app.post('/api/seller/products',auth,allow('SELLER'),wrap(async(req,res)=>{
 const u=await prisma.user.findUnique({where:{id:req.auth.sub}});
 if(u.sellerStatus!=='APPROVED')return res.status(403).json({message:'Seller approval is pending'});
 const s=z.object({name:z.string().min(2).max(120),description:z.string().max(1000).default(''),category:z.string().min(2).max(40),price:z.number().positive(),stock:z.number().int().min(0)}).parse(req.body);
 const p=await prisma.product.create({data:{...s,sellerId:u.id}});res.status(201).json(p);
}));
app.get('/api/seller/products',auth,allow('SELLER'),wrap(async(req,res)=>{
 res.json(await prisma.product.findMany({where:{sellerId:req.auth.sub},orderBy:{createdAt:'desc'}}));
}));
app.patch('/api/seller/products/:id',auth,allow('SELLER'),wrap(async(req,res)=>{
 const p=await prisma.product.findFirst({where:{id:req.params.id,sellerId:req.auth.sub}});
 if(!p)return res.status(404).json({message:'Product not found'});
 const s=z.object({name:z.string().min(2).max(120).optional(),description:z.string().max(1000).optional(),category:z.string().min(2).max(40).optional(),price:z.number().positive().optional(),stock:z.number().int().min(0).optional(),active:z.boolean().optional()}).parse(req.body);
 res.json(await prisma.product.update({where:{id:p.id},data:s}));
}));
app.post('/api/orders',auth,allow('CUSTOMER'),wrap(async(req,res)=>{
 const s=z.object({items:z.array(z.object({productId:z.string(),quantity:z.number().int().min(1).max(50)})).min(1).max(30),paymentMethod:z.enum(['COD']).default('COD')}).parse(req.body);
 const ids=s.items.map(x=>x.productId);
 const products=await prisma.product.findMany({where:{id:{in:ids},active:true}});
 if(products.length!==new Set(ids).size)return res.status(400).json({message:'One or more products are unavailable'});
 let total=0;const items=[];
 for(const line of s.items){const p=products.find(x=>x.id===line.productId);if(!p||p.stock<line.quantity)return res.status(400).json({message:`Insufficient stock for ${p?.name||'product'}`});total+=Number(p.price)*line.quantity;items.push({productId:p.id,quantity:line.quantity,unitPrice:p.price})}
 const order=await prisma.$transaction(async tx=>{
  for(const line of s.items){const p=products.find(x=>x.id===line.productId);await tx.product.update({where:{id:p.id},data:{stock:{decrement:line.quantity}}})}
  return tx.order.create({data:{customerId:req.auth.sub,paymentMethod:s.paymentMethod,total,items:{create:items}},include:{items:{include:{product:true}}}});
 });
 res.status(201).json({id:order.id,total:Number(order.total),status:order.status,paymentMethod:order.paymentMethod});
}));
app.get('/api/orders/mine',auth,allow('CUSTOMER'),wrap(async(req,res)=>{
 const rows=await prisma.order.findMany({where:{customerId:req.auth.sub},include:{items:{include:{product:true}}},orderBy:{createdAt:'desc'}});
 res.json(rows);
}));
app.get('/api/seller/orders',auth,allow('SELLER'),wrap(async(req,res)=>{
 const rows=await prisma.order.findMany({where:{items:{some:{product:{sellerId:req.auth.sub}}}},include:{customer:{select:{name:true,email:true}},items:{include:{product:true}}},orderBy:{createdAt:'desc'}});
 res.json(rows);
}));
app.get('/api/admin/overview',auth,allow('ADMIN'),wrap(async(req,res)=>{
 const [users,products,orders,pendingSellers]=await Promise.all([prisma.user.count(),prisma.product.count(),prisma.order.count(),prisma.user.count({where:{sellerStatus:'PENDING',role:'SELLER'}})]);
 res.json({users,products,orders,pendingSellers});
}));
app.get('/api/admin/sellers',auth,allow('ADMIN'),wrap(async(req,res)=>res.json(await prisma.user.findMany({where:{role:'SELLER'},select:{id:true,name:true,email:true,storeName:true,sellerStatus:true,createdAt:true}}))));
app.patch('/api/admin/sellers/:id',auth,allow('ADMIN'),wrap(async(req,res)=>{
 const s=z.object({status:z.enum(['APPROVED','REJECTED'])}).parse(req.body);
 const u=await prisma.user.update({where:{id:req.params.id},data:{sellerStatus:s.status}});res.json(userView(u));
}));
app.get('/api/admin/orders',auth,allow('ADMIN'),wrap(async(req,res)=>res.json(await prisma.order.findMany({include:{customer:{select:{name:true,email:true}},items:{include:{product:true}}},orderBy:{createdAt:'desc'}}))));
app.patch('/api/admin/products/:id',auth,allow('ADMIN'),wrap(async(req,res)=>{
 const s=z.object({active:z.boolean()}).parse(req.body);res.json(await prisma.product.update({where:{id:req.params.id},data:s}));
}));
app.use((err,req,res,next)=>{
 if(err instanceof z.ZodError)return res.status(400).json({message:'Invalid input',issues:err.issues.map(i=>({field:i.path.join('.'),message:i.message}))});
 console.error(err);res.status(500).json({message:'Internal server error'});
});
const port=Number(process.env.PORT||4000);app.listen(port,()=>console.log(`Ventex API listening on ${port}`));
