import 'dotenv/config';
import bcrypt from 'bcryptjs';
import {PrismaClient} from '@prisma/client';
const prisma=new PrismaClient();
try{
 const passwordHash=await bcrypt.hash('ChangeMe123!',12);
 await prisma.user.upsert({where:{email:'admin@ventex.local'},update:{},create:{name:'Ventex Admin',email:'admin@ventex.local',passwordHash,role:'ADMIN',sellerStatus:'APPROVED'}});
 const sellerHash=await bcrypt.hash('SellerDemo123!',12);
 const seller=await prisma.user.upsert({where:{email:'seller@ventex.local'},update:{},create:{name:'Demo Seller',email:'seller@ventex.local',passwordHash:sellerHash,role:'SELLER',sellerStatus:'APPROVED',storeName:'Studio North'}});
 const demo=[['Studio Headphones','Wireless audio for everyday listening','Electronics',79.99,25],['Everyday Tote','Minimal carry-all bag','Fashion',34.50,40],['Ceramic Vase','A simple accent for your home','Home',28,18],['Glow Skincare Set','A three-piece daily routine','Beauty',45,20],['Trail Bottle','Reusable bottle for active days','Sports',22.99,50]];
 for(const [name,description,category,price,stock] of demo)await prisma.product.create({data:{name,description,category,price,stock,sellerId:seller.id}});
 console.log('Seed complete');
}finally{await prisma.$disconnect()}
