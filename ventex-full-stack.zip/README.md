# Ventex Marketplace — Full-stack starter

A responsive marketplace starter with a customer storefront, customer accounts, seller application/product management, admin moderation, and order checkout.

## Stack
- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Node.js + Express
- Database: PostgreSQL + Prisma ORM
- Authentication: JWT + bcrypt password hashing
- Security: Helmet, CORS allow-list, rate limiting, Zod validation

## What works
- Register/login; passwords are hashed with bcrypt (never returned or logged)
- Role-based access: CUSTOMER, SELLER, ADMIN
- Product listing/search/category filtering
- Cart stored in browser localStorage
- Customer checkout creates an order (demo cash-on-delivery workflow)
- Seller application and admin approval
- Seller can create/update own products and view own orders
- Admin can approve sellers, manage products, and view orders

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. Create a PostgreSQL database named `ventex`.
3. Copy `server/.env.example` to `server/.env` and set `DATABASE_URL`, `JWT_SECRET`, and `CLIENT_ORIGIN`.
4. In a terminal:
   ```bash
   cd server
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   npm run seed
   npm run dev
   ```
5. Serve the `client` folder with any static server (for example VS Code Live Server) at the `CLIENT_ORIGIN` URL.

Seeded admin:
- Email: `admin@ventex.local`
- Password: `ChangeMe123!`

Change this password immediately after first login. The seed creates demo products too.

## Important before production
- Configure HTTPS and a strict `CLIENT_ORIGIN`.
- Set a long random JWT secret; rotate it periodically.
- Add email verification, password reset, audit logs, backups, monitoring, and fraud controls.
- Integrate a real payment provider (Stripe/SSLCommerz/bKash etc.) using server-side verified webhooks. This starter does NOT collect card details or claim payments are live.
- Review local tax, privacy, consumer protection, shipping, and refund requirements.
- Never store raw card data or plaintext passwords.
